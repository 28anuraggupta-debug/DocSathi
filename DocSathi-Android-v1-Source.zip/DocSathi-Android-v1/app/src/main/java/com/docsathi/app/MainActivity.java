package com.docsathi.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(25,25,25)); t.setPadding(24,18,24,18); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(17); return b; }
    public void onCreate(Bundle b){super.onCreate(b); showHome();}
    void showHome(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,25,20,20);
        TextView h=tv("DocSathi",30); h.setTextColor(Color.rgb(21,101,192)); root.addView(h);
        root.addView(tv("कागज़ समझना है? बस फोटो डालें।",22));
        Button cam=btn("📷  Camera से फोटो लें"), gal=btn("🖼️  Gallery से फोटो चुनें"); root.addView(cam); root.addView(gal);
        root.addView(tv("1–6 फोटो जोड़ सकते हैं।",16));
        cam.setOnClickListener(v->{startActivityForResult(new Intent(MediaStore.ACTION_IMAGE_CAPTURE),10);});
        gal.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); startActivityForResult(i,20);});
        setContentView(root);
    }
    protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(c==RESULT_OK) showResult();}
    void showResult(){
        root.removeAllViews(); root.addView(tv("📄 फोटो मिल गई",27));
        root.addView(tv("AI analysis के लिए तैयार है।\n\n📝 आसान भाषा में मतलब\n\n⚠️ आपको क्या करना है?\n\n📅 महत्वपूर्ण तारीख\n\n💰 पैसे / रकम\n\n👤 किसके लिए है?\n\n🔎 ध्यान देने वाली बात",18));
        Button back=btn("← दूसरी फोटो चुनें"); root.addView(back); back.setOnClickListener(v->showHome());
    }
}
