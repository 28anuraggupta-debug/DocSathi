DocSathi Android v1 source project.
This is the Android app source with Camera/Gallery UI. It is not an APK yet because this environment does not have a configured Android SDK/Gradle build toolchain.
