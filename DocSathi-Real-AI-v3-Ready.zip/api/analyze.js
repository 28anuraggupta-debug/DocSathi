const OpenAI = require('openai');

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

function send(res, code, body) {
  res.statusCode = code;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.end(JSON.stringify(body));
}

module.exports = async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  if (req.method !== 'POST') return send(res, 405, { error: 'POST required' });
  try {
    const images = Array.isArray(req.body?.images) ? req.body.images : [];
    const language = ['hi', 'en', 'mr'].includes(req.body?.language) ? req.body.language : 'hi';
    if (!images.length || images.length > 6) return send(res, 400, { error: '1 to 6 images required' });

    const content = [{
      type: 'input_text',
      text: `You are DocSathi, an AI assistant that explains photographed documents, letters, bills, receipts, property papers/maps, notices, and medicine packaging in simple language. Analyze every image carefully and combine them as pages of one document. Respond in ${language === 'hi' ? 'Hindi (Devanagari)' : language === 'mr' ? 'Marathi (Devanagari)' : 'English'}.

Rules:
- Read visible text, dates, amounts, names, addresses, numbers, warnings and instructions as accurately as possible.
- Never invent missing information. If something is unreadable, say so.
- For medicine packaging, explain only what is visibly written and add that medicine use/dose should be confirmed with a doctor/pharmacist.
- For legal/property papers, explain what the document appears to say, not legal advice.
- Return concise, useful sections.
- IMPORTANT: return ONLY JSON matching the supplied schema.`
    }];

    for (const img of images) {
      if (typeof img !== 'string' || !img.startsWith('data:image/')) continue;
      content.push({ type: 'input_image', image_url: img, detail: 'high' });
    }

    const response = await client.responses.create({
      model: 'gpt-5.6',
      store: false,
      input: [{ role: 'user', content }],
      text: {
        format: {
          type: 'json_schema',
          name: 'docsathi_analysis',
          strict: true,
          schema: {
            type: 'object',
            additionalProperties: false,
            properties: {
              document_type: { type: 'string' },
              simple_meaning: { type: 'string' },
              action: { type: 'string' },
              important_date: { type: 'string' },
              money: { type: 'string' },
              for_whom: { type: 'string' },
              attention: { type: 'string' }
            },
            required: ['document_type','simple_meaning','action','important_date','money','for_whom','attention']
          }
        }
      }
    });

    let parsed;
    try { parsed = JSON.parse(response.output_text); }
    catch (_) { return send(res, 502, { error: 'AI returned an unexpected response' }); }
    return send(res, 200, { analysis: parsed });
  } catch (e) {
    console.error(e);
    return send(res, 500, { error: 'AI analysis failed. Please try again.' });
  }
};
