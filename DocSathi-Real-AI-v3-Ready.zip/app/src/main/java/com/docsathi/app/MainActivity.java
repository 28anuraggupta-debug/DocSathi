package com.docsathi.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.*;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 100;
    private static final int REQ_CAMERA_PHOTO = 10;
    private static final int REQ_GALLERY = 20;
    // After deploying the Vercel backend, replace this URL with your /api/analyze URL.
    private static final String API_URL = "https://REPLACE-WITH-YOUR-VERCEL-DOMAIN.vercel.app/api/analyze";
    private Uri cameraUri;
    private final ArrayList<Uri> imageUris = new ArrayList<>();
    LinearLayout root;

    TextView tv(String s, int sp) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp);
        t.setTextColor(Color.rgb(25,25,25)); t.setPadding(24,18,24,18); return t;
    }
    Button btn(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(17); return b; }

    @Override public void onCreate(Bundle b) { super.onCreate(b); showHome(); }

    void showHome() {
        imageUris.clear();
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,25,20,20);
        TextView h = tv("DocSathi",30); h.setTextColor(Color.rgb(21,101,192)); root.addView(h);
        root.addView(tv("कागज़ समझना है? बस फोटो डालें।",22));
        Button cam = btn("📷  Camera से फोटो लें");
        Button gal = btn("🖼️  Gallery से फोटो चुनें");
        root.addView(cam); root.addView(gal); root.addView(tv("1–6 फोटो जोड़ सकते हैं।",16));
        cam.setOnClickListener(v -> openCameraSafely());
        gal.setOnClickListener(v -> openGallery());
        setContentView(root);
    }

    private void openCameraSafely() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA); return;
        }
        launchCamera();
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "images");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("camera cache unavailable");
            File photo = File.createTempFile("docsathi_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(this, "com.docsathi.app.fileprovider", photo);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, REQ_CAMERA_PHOTO);
            else Toast.makeText(this, "फोन में कैमरा उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "कैमरा खोलने में समस्या हुई।", Toast.LENGTH_LONG).show(); }
    }

    private void openGallery() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_GALLERY);
        } catch (ActivityNotFoundException e) { Toast.makeText(this, "Gallery/File picker नहीं मिला।", Toast.LENGTH_LONG).show(); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else Toast.makeText(this, "Camera permission नहीं मिली।", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (c != RESULT_OK) return;
        if (r == REQ_CAMERA_PHOTO && cameraUri != null) {
            imageUris.clear(); imageUris.add(cameraUri); analyzeImages();
        } else if (r == REQ_GALLERY && d != null) {
            imageUris.clear();
            if (d.getClipData() != null) {
                int n = Math.min(6, d.getClipData().getItemCount());
                for (int i=0;i<n;i++) imageUris.add(d.getClipData().getItemAt(i).getUri());
            } else if (d.getData() != null) imageUris.add(d.getData());
            if (!imageUris.isEmpty()) analyzeImages();
        }
    }

    void analyzeImages() {
        root.removeAllViews();
        TextView title = tv("🤖 DocSathi पढ़ रहा है…",25); title.setGravity(Gravity.CENTER); root.addView(title);
        ProgressBar p = new ProgressBar(this); root.addView(p);
        root.addView(tv("फोटो का टेक्स्ट और जरूरी जानकारी समझी जा रही है।\nथोड़ा समय लग सकता है।",17));
        new Thread(() -> {
            try {
                if (API_URL.contains("REPLACE-WITH-YOUR")) throw new Exception("AI server अभी connect नहीं है।");
                JSONObject body = new JSONObject();
                org.json.JSONArray arr = new org.json.JSONArray();
                for (Uri u : imageUris) arr.put(toDataUrl(u));
                body.put("images", arr); body.put("language", "hi");
                String response = postJson(body.toString());
                JSONObject obj = new JSONObject(response);
                if (obj.has("error")) throw new Exception(obj.getString("error"));
                JSONObject a = obj.getJSONObject("analysis");
                runOnUiThread(() -> showRealResult(a));
            } catch (Exception e) {
                runOnUiThread(() -> showError(e.getMessage()));
            }
        }).start();
    }

    String toDataUrl(Uri uri) throws Exception {
        Bitmap b = BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));
        if (b == null) throw new IOException("फोटो पढ़ी नहीं जा सकी");
        int max = 1200; float scale = Math.min(1f, max / (float)Math.max(b.getWidth(), b.getHeight()));
        if (scale < 1f) b = Bitmap.createScaledBitmap(b, Math.round(b.getWidth()*scale), Math.round(b.getHeight()*scale), true);
        ByteArrayOutputStream out = new ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 65, out); b.recycle();
        String base64 = Base64.getEncoder().encodeToString(out.toByteArray());
        return "data:image/jpeg;base64," + base64;
    }

    String postJson(String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(API_URL).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        try (OutputStream os = c.getOutputStream()) { os.write(json.getBytes(StandardCharsets.UTF_8)); }
        InputStream is = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n;
        while ((n=is.read(buf))!=-1) out.write(buf,0,n);
        String s = out.toString("UTF-8"); if (c.getResponseCode() >= 400) throw new Exception(s); return s;
    }

    void showRealResult(JSONObject a) {
        root.removeAllViews(); root.addView(tv("📄 यह कागज़ क्या है?\n" + a.optString("document_type"),20));
        root.addView(tv("📝 आसान भाषा में मतलब\n" + a.optString("simple_meaning"),18));
        root.addView(tv("⚠️ आपको क्या करना है?\n" + a.optString("action"),18));
        root.addView(tv("📅 महत्वपूर्ण तारीख\n" + a.optString("important_date"),18));
        root.addView(tv("💰 पैसे / रकम\n" + a.optString("money"),18));
        root.addView(tv("👤 किसके लिए है?\n" + a.optString("for_whom"),18));
        root.addView(tv("🔎 ध्यान देने वाली बात\n" + a.optString("attention"),18));
        Button back = btn("← दूसरी फोटो चुनें"); root.addView(back); back.setOnClickListener(v -> showHome());
    }

    void showError(String msg) {
        root.removeAllViews(); root.addView(tv("⚠️ AI analysis नहीं हो पाया",24));
        root.addView(tv(msg == null ? "कृपया फिर कोशिश करें।" : msg,18));
        Button retry = btn("↻ फिर कोशिश करें"); root.addView(retry); retry.setOnClickListener(v -> showHome());
    }
}
