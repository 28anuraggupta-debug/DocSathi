DocSathi Real-AI v2.1

Backend:
- Vercel function: api/analyze.js
- Add OPENAI_API_KEY as a Vercel Environment Variable.
- Deploy the project.
- Copy the deployed URL and replace API_URL in MainActivity.java:
  https://YOUR-VERCEL-DOMAIN.vercel.app/api/analyze

Security:
- Never put the OpenAI API key inside the Android APK or GitHub source.
- The key belongs only in Vercel Environment Variables.

Android:
- Camera and Gallery are supported.
- 1–6 images are sent as JPEG data URLs.
- The app displays the structured AI analysis after the backend URL is configured.
