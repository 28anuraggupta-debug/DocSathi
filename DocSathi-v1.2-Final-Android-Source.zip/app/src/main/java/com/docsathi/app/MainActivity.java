package com.docsathi.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 100;
    private static final int REQ_CAMERA_PHOTO = 10;
    private static final int REQ_GALLERY = 20;
    private Uri cameraUri;
    LinearLayout root;

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(25,25,25));
        t.setPadding(24,18,24,18); return t;
    }
    Button btn(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(17); return b; }

    @Override public void onCreate(Bundle b) { super.onCreate(b); showHome(); }

    void showHome() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,25,20,20);
        TextView h = tv("DocSathi",30); h.setTextColor(Color.rgb(21,101,192)); root.addView(h);
        root.addView(tv("कागज़ समझना है? बस फोटो डालें।",22));
        Button cam = btn("📷  Camera से फोटो लें");
        Button gal = btn("🖼️  Gallery से फोटो चुनें");
        root.addView(cam); root.addView(gal); root.addView(tv("1–6 फोटो जोड़ सकते हैं।",16));
        cam.setOnClickListener(v -> openCameraSafely());
        gal.setOnClickListener(v -> openGallery());
        setContentView(root);
    }

    private void openCameraSafely() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA); return;
        }
        launchCamera();
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "images");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("camera cache unavailable");
            File photo = File.createTempFile("docsathi_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(this, "com.docsathi.app.fileprovider", photo);
            Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, REQ_CAMERA_PHOTO);
            else Toast.makeText(this, "फोन में कैमरा उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "कैमरा ऐप नहीं मिला।", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "कैमरा खोलने में समस्या हुई।", Toast.LENGTH_LONG).show();
        }
    }

    private void openGallery() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_GALLERY);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Gallery/File picker नहीं मिला।", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else Toast.makeText(this, "Camera permission नहीं मिली।", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (c == RESULT_OK && r == REQ_CAMERA_PHOTO && cameraUri != null) showResult("कैमरे से फोटो मिल गई।");
        else if (c == RESULT_OK && r == REQ_GALLERY) showResult("Gallery से फोटो मिल गई।");
    }

    void showResult(String msg) {
        root.removeAllViews(); root.addView(tv("📄 फोटो मिल गई",27));
        root.addView(tv(msg + "\n\nAI analysis के लिए तैयार है।\n\n📝 आसान भाषा में मतलब\n\n⚠️ आपको क्या करना है?\n\n📅 महत्वपूर्ण तारीख\n\n💰 पैसे / रकम\n\n👤 किसके लिए है?\n\n🔎 ध्यान देने वाली बात",18));
        Button back = btn("← दूसरी फोटो चुनें"); root.addView(back); back.setOnClickListener(v -> showHome());
    }
}
