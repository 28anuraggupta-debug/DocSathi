DocSathi Android v1.2 - Camera crash fix

Fixes:
- Uses FileProvider + a real temporary image URI for the camera.
- Requests CAMERA runtime permission before launching camera.
- Handles missing camera app and errors without crashing.
- Gallery multi-select remains available.
- AndroidX enabled in gradle.properties.

This is a UI prototype; AI analysis is not connected in this Android source yet.
