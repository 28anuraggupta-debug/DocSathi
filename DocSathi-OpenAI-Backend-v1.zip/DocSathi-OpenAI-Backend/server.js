const http = require("http");

const PORT = process.env.PORT || 10000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";

const MAX_IMAGES = 6;
const MAX_BODY_BYTES = 28 * 1024 * 1024;
const WINDOW_MS = 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = 10;
const hits = new Map();

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    document_type: { type: "string" },
    simple_meaning: { type: "string" },
    action: { type: "string" },
    important_date: { type: "string" },
    money: { type: "string" },
    for_whom: { type: "string" },
    attention: { type: "string" }
  },
  required: [
    "document_type",
    "simple_meaning",
    "action",
    "important_date",
    "money",
    "for_whom",
    "attention"
  ]
};

const PROMPT = `
You are DocSathi, a document-understanding assistant for Indian users.
Analyze all attached photos as pages of ONE document.

Explain the document in simple Hindi (Devanagari). Read visible text, dates,
amounts, names, addresses, numbers, warnings and instructions accurately.

Rules:
- Never invent information. If something is unreadable or absent, say that.
- Preserve important numbers, dates and amounts exactly when readable.
- For medicine packaging, explain only visible information and say dose/use
  should be confirmed with a doctor or pharmacist.
- For legal/property papers, explain what the document appears to say;
  do not present the explanation as legal advice.
- Keep the answer practical and easy to understand.

Return exactly the seven requested fields.
`;

function send(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(JSON.stringify(data));
}

function getClientIp(req) {
  return (req.headers["x-forwarded-for"] || "").split(",")[0].trim()
    || req.socket.remoteAddress
    || "unknown";
}

function allowed(ip) {
  const now = Date.now();
  const old = hits.get(ip) || [];
  const recent = old.filter(t => now - t < WINDOW_MS);
  recent.push(now);
  hits.set(ip, recent);
  return recent.length <= MAX_REQUESTS_PER_WINDOW;
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", chunk => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new Error("Request बहुत बड़ा है। कृपया कम/छोटी photos भेजें।"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8"))); }
      catch { reject(new Error("Invalid JSON request.")); }
    });
    req.on("error", reject);
  });
}

async function analyze(images) {
  const content = [
    { type: "input_text", text: PROMPT },
    ...images.map(image_url => ({
      type: "input_image",
      image_url,
      detail: "high"
    }))
  ];

  const payload = {
    model: MODEL,
    store: false,
    input: [{
      role: "user",
      content
    }],
    text: {
      format: {
        type: "json_schema",
        name: "docsathi_analysis",
        strict: true,
        schema
      }
    }
  };

  const r = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  const raw = await r.text();
  if (!r.ok) {
    let message = raw;
    try {
      const j = JSON.parse(raw);
      message = j.error?.message || raw;
    } catch {}
    throw new Error(message);
  }

  const data = JSON.parse(raw);
  if (data.output_text) return JSON.parse(data.output_text);

  // Defensive fallback for response shapes.
  const parts = [];
  for (const item of (data.output || [])) {
    for (const c of (item.content || [])) {
      if (c.type === "output_text" && c.text) parts.push(c.text);
    }
  }
  const text = parts.join("");
  if (!text) throw new Error("AI ने कोई readable result नहीं दिया।");
  return JSON.parse(text);
}

const server = http.createServer(async (req, res) => {
  // Basic CORS for the Android client and future web clients.
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");

  if (req.method === "OPTIONS") return send(res, 204, {});
  if (req.method === "GET" && req.url === "/health") {
    return send(res, 200, { ok: true, service: "DocSathi AI backend" });
  }

  if (req.method !== "POST" || req.url !== "/analyze") {
    return send(res, 404, { error: "Not found" });
  }

  if (!OPENAI_API_KEY) {
    return send(res, 500, { error: "OPENAI_API_KEY server पर सेट नहीं है।" });
  }

  if (!allowed(getClientIp(req))) {
    return send(res, 429, { error: "बहुत ज्यादा requests। एक मिनट बाद फिर कोशिश करें।" });
  }

  try {
    const body = await readJson(req);
    const images = Array.isArray(body.images) ? body.images : [];

    if (images.length < 1 || images.length > MAX_IMAGES) {
      return send(res, 400, { error: "1 से 6 images भेजें।" });
    }

    for (const image of images) {
      if (typeof image !== "string" ||
          !/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(image)) {
        return send(res, 400, { error: "Invalid image format." });
      }
    }

    const result = await analyze(images);
    return send(res, 200, result);
  } catch (e) {
    return send(res, 500, { error: e.message || "Server error" });
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`DocSathi backend listening on ${PORT}; model=${MODEL}`);
});
