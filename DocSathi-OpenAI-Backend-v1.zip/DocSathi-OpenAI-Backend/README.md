# DocSathi OpenAI Backend

This server keeps the OpenAI API key off the Android APK.

## Environment variables

- `OPENAI_API_KEY` — your OpenAI secret key. Put it in Render Environment Variables. Do NOT put it in GitHub files or the APK.
- `OPENAI_MODEL` — defaults to `gpt-5.6-luna`.

## Endpoints

- `GET /health`
- `POST /analyze` with JSON:
  `{ "images": ["data:image/jpeg;base64,..."] }`

The server uses OpenAI's Responses API with image inputs and Structured Outputs.
It returns the seven DocSathi fields as JSON.

## Render

Create a free Web Service from this folder/repository, choose the Free plan,
then add `OPENAI_API_KEY` under Environment Variables. Render free web services
are intended for testing/hobby projects and may sleep when idle.
