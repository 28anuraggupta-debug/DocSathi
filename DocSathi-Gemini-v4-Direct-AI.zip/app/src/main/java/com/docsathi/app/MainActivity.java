package com.docsathi.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.*;
import androidx.core.content.FileProvider;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA=100, REQ_CAMERA_PHOTO=10, REQ_GALLERY=20;
    private static final String GEMINI_URL="https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent";
    private static final String PREF="docsathi"; private static final String KEY="gemini_api_key";
    private Uri cameraUri; private final ArrayList<Uri> imageUris=new ArrayList<>(); LinearLayout root;
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(25,25,25)); t.setPadding(24,18,24,18); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(17); return b; }
    @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
    String savedKey(){return getSharedPreferences(PREF,0).getString(KEY,"");}
    void showHome(){
        imageUris.clear(); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,25,20,20);
        TextView h=tv("DocSathi",30); h.setTextColor(Color.rgb(21,101,192)); root.addView(h);
        root.addView(tv("कागज़ समझना है? बस फोटो डालें।",22));
        Button cam=btn("📷  Camera से फोटो लें"), gal=btn("🖼️  Gallery से फोटो चुनें"), key=btn("🔑  Gemini API Key सेट करें");
        root.addView(cam); root.addView(gal); root.addView(tv("1–6 फोटो जोड़ सकते हैं।",16)); root.addView(key);
        TextView status=tv(savedKey().isEmpty()?"AI अभी सेट नहीं है। API Key सेट करें।":"✅ Gemini AI तैयार है",15); root.addView(status);
        cam.setOnClickListener(v->openCameraSafely()); gal.setOnClickListener(v->openGallery()); key.setOnClickListener(v->showKeyDialog()); setContentView(root);
    }
    void showKeyDialog(){
        final EditText input=new EditText(this); input.setHint("AIza... API key"); input.setSingleLine(false); input.setText(savedKey());
        LinearLayout box=new LinearLayout(this); box.setPadding(30,10,30,0); box.addView(input);
        new AlertDialog.Builder(this).setTitle("Gemini API Key").setMessage("Key केवल इस फोन में सेव होगी। इसे किसी को भेजना मत।").setView(box)
          .setNegativeButton("रद्द",null).setPositiveButton("सेव",(d,w)->{String k=input.getText().toString().trim(); getSharedPreferences(PREF,0).edit().putString(KEY,k).apply(); showHome();}).show();
    }
    void openCameraSafely(){ if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);return;} launchCamera(); }
    void launchCamera(){try{File dir=new File(getCacheDir(),"images");if(!dir.exists()&&!dir.mkdirs())throw new IOException();File photo=File.createTempFile("docsathi_",".jpg",dir);cameraUri=FileProvider.getUriForFile(this,"com.docsathi.app.fileprovider",photo);Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);if(i.resolveActivity(getPackageManager())!=null)startActivityForResult(i,REQ_CAMERA_PHOTO);else Toast.makeText(this,"फोन में कैमरा उपलब्ध नहीं है।",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"कैमरा खोलने में समस्या हुई।",Toast.LENGTH_LONG).show();}}
    void openGallery(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_GALLERY);}catch(Exception e){Toast.makeText(this,"Gallery/File picker नहीं मिला।",Toast.LENGTH_LONG).show();}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_CAMERA){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)launchCamera();else Toast.makeText(this,"Camera permission नहीं मिली।",Toast.LENGTH_LONG).show();}}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK)return;if(r==REQ_CAMERA_PHOTO&&cameraUri!=null){imageUris.clear();imageUris.add(cameraUri);analyzeImages();}else if(r==REQ_GALLERY&&d!=null){imageUris.clear();if(d.getClipData()!=null){int n=Math.min(6,d.getClipData().getItemCount());for(int i=0;i<n;i++)imageUris.add(d.getClipData().getItemAt(i).getUri());}else if(d.getData()!=null)imageUris.add(d.getData());if(!imageUris.isEmpty())analyzeImages();}}
    void analyzeImages(){
        if(savedKey().isEmpty()){showKeyDialog();return;}
        root.removeAllViews();TextView title=tv("🤖 DocSathi पढ़ रहा है…",25);title.setGravity(Gravity.CENTER);root.addView(title);ProgressBar p=new ProgressBar(this);root.addView(p);root.addView(tv("Gemini AI फोटो का टेक्स्ट और जरूरी जानकारी समझ रहा है।\nथोड़ा समय लग सकता है।",17));
        new Thread(()->{try{String response=callGemini();JSONObject json=new JSONObject(response);String text=json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");JSONObject a=new JSONObject(cleanJson(text));runOnUiThread(()->showRealResult(a));}catch(Exception e){runOnUiThread(()->showError(e.getMessage()));}}).start();
    }
    String cleanJson(String s){s=s.trim();if(s.startsWith("```")){int a=s.indexOf('{'),b=s.lastIndexOf('}');if(a>=0&&b>a)s=s.substring(a,b+1);}return s;}
    String callGemini() throws Exception{
        JSONObject body=new JSONObject();JSONArray parts=new JSONArray();
        String prompt="You are DocSathi. Analyze all attached photos as pages of one document. Explain photographed documents, letters, bills, receipts, property papers/maps, notices and medicine packaging in simple Hindi (Devanagari). Read visible text, dates, amounts, names, addresses, numbers, warnings and instructions accurately. Never invent missing information; if unreadable say so. For medicine packaging, explain only visible information and say dose/use should be confirmed with a doctor/pharmacist. For legal/property papers, explain what it appears to say, not legal advice. Return ONLY valid JSON with exactly these string fields: document_type, simple_meaning, action, important_date, money, for_whom, attention.";
        parts.put(new JSONObject().put("text",prompt));
        for(Uri u:imageUris){Bitmap b=BitmapFactory.decodeStream(getContentResolver().openInputStream(u));if(b==null)throw new IOException("फोटो पढ़ी नहीं जा सकी");int max=1400;float scale=Math.min(1f,max/(float)Math.max(b.getWidth(),b.getHeight()));if(scale<1)b=Bitmap.createScaledBitmap(b,Math.round(b.getWidth()*scale),Math.round(b.getHeight()*scale),true);ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,68,out);b.recycle();String b64=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);parts.put(new JSONObject().put("inlineData",new JSONObject().put("mimeType","image/jpeg").put("data",b64)));}
        JSONArray contents=new JSONArray().put(new JSONObject().put("parts",parts));body.put("contents",contents);JSONObject cfg=new JSONObject().put("responseMimeType","application/json").put("temperature",0.2);body.put("generationConfig",cfg);
        HttpURLConnection c=(HttpURLConnection)new URL(GEMINI_URL).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(20000);c.setReadTimeout(90000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("x-goog-api-key",savedKey());try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))!=-1)out.write(buf,0,n);String s=out.toString("UTF-8");if(code>=400)throw new Exception(s);return s;
    }
    void showRealResult(JSONObject a){root.removeAllViews();root.addView(tv("📄 यह कागज़ क्या है?\n"+a.optString("document_type"),20));root.addView(tv("📝 आसान भाषा में मतलब\n"+a.optString("simple_meaning"),18));root.addView(tv("⚠️ आपको क्या करना है?\n"+a.optString("action"),18));root.addView(tv("📅 महत्वपूर्ण तारीख\n"+a.optString("important_date"),18));root.addView(tv("💰 पैसे / रकम\n"+a.optString("money"),18));root.addView(tv("👤 किसके लिए है?\n"+a.optString("for_whom"),18));root.addView(tv("🔎 ध्यान देने वाली बात\n"+a.optString("attention"),18));Button back=btn("← दूसरी फोटो चुनें");root.addView(back);back.setOnClickListener(v->showHome());}
    void showError(String msg){root.removeAllViews();root.addView(tv("⚠️ AI analysis नहीं हो पाया",24));root.addView(tv(msg==null?"कृपया फिर कोशिश करें।":msg,16));Button retry=btn("↻ फिर कोशिश करें");root.addView(retry);retry.setOnClickListener(v->showHome());}
}
