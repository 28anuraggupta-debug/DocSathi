DocSathi Gemini Direct AI v4

This test build calls Gemini 3.8 Flash directly from the phone. Enter your Gemini API key using the in-app button. Do NOT distribute this build publicly: API keys stored on-device can potentially be extracted. For public release, move the key to a secure backend.

Gemini 3.8 Flash supports image input and structured JSON output.
